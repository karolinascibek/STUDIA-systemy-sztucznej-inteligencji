from blok1.lab1.decision_system import DecisionSystem
from blok1.lab4.one_plus_one import OnePlusOne
from blok1.lab4.mu_plus_lambda import MuPlusLambda


system = DecisionSystem()

# -- lab 4.1 --
# opo = OnePlusOne()
# opo.one_plus_one(l_iteracji=20)

# -- lab 4.2 --
mpl = MuPlusLambda()
mpl.mu_plus_lambda(m=3, l=10)



