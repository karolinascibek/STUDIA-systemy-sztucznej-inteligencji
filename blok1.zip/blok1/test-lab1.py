from blok1.lab1.decision_system import DecisionSystem

system = DecisionSystem()

# -- lab1 --

system.load_samples("lab1/wartosci.txt")
system.load_headers("lab1/atrybuty.txt")

system.display()



