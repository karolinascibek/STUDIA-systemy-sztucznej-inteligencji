biblioteki do zainstalowania:
* matplotlib
* tabulate
* numpy

`pip install nazwa_biblioteki`